# EmployeeHub — Advanced Employee Management System

Frontend internship demo with 5,000 employee records.

## Features
- 5,000 generated employee profiles
- Pagination: 25 employees per page
- Fast client-side search
- Department and status filters
- Individual employee profiles
- Add Employee on a separate page
- Attendance linked to employees
- Leave balances linked to employees
- Performance ratings and goals linked to employees
- Employee CSV export
- Attendance CSV export
- Responsive dark enterprise UI
- Browser localStorage persistence

## GitHub Pages
Upload the contents of this folder to your repository root.
Then open GitHub repository Settings → Pages and deploy the main branch from the root folder.

## Demo-data note
The 5,000 records are generated automatically in the browser on first load, keeping the GitHub repository lightweight. Do not use this frontend-only demo for real employee personal information without a secure backend, authentication, authorization, and database.
